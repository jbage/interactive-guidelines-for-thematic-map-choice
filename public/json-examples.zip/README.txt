Make sure to safe your decision tree file in the same folder as the json-schema.json to validate it while converting the decision tree. 
You can use template.json to convert your own decision tree into the format. 
If your editor supports the feature (e. g. Visual Studio Code), you can hover over attributes to receive a description and examples are suggested when editing the attributes. Also incorrect attributes are highlighted.
Else you can check the schema file (json-schema.json). 
Ensure that the IDs of the nodes are unique.